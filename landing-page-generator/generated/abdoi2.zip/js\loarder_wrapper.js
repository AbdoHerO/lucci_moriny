// window.addEventListener("load", function () {
//   $(".loader").hide();
//   $("body").removeClass("body_fixed");
// });

// document.addEventListener("DOMContentLoaded", function () {
//     var loaderWrapper = document.getElementById("loader-wrapper");
//     loaderWrapper.style.display = "none";
//   });

// setTimeout(function () {
//   $(".loader").hide();
//   $("body").removeClass("body_fixed");
// }, 100); // 500 milliseconds (0.5 seconds) delay

$(".loader").hide();
$("body").removeClass("body_fixed");